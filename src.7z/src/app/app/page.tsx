import { redirect } from "next/navigation"

export default function AppEntryPage() {
  redirect("/app/loja")
}
